Two observations that might not be obvious for the untrained eye:

1) the images in this sequence are upside down (make sure the checkbox "Flip" is checked)
2) there are 4 perforation holes per frame (make sure the "Perfs per frame" spinbox is set to 4)
